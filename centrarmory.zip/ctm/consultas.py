from models import Session, Efetivo

def consulta_maiores_de_30():
    session = Session()
    resultado = session.query(Efetivo).filter(Efetivo.Idade > 30).all()
    print("Militares com mais de 30 anos:")
    for e in resultado:
        print(e.NomeGuerra, e.Idade)
    session.close()

def consulta_patente(patente):
    session = Session()
    resultado = session.query(Efetivo).filter(Efetivo.Patente == patente).all()
    print(f"Militares com patente {patente}:")
    for e in resultado:
        print(e.NomeGuerra)
    session.close()

def consulta_com_imediato():
    session = Session()
    resultado = session.query(Efetivo).filter(Efetivo.Imediato_NomeGuerra != None).all()
    print("Militares que têm imediato:")
    for e in resultado:
        print(e.NomeGuerra, "-> Imediato:", e.Imediato_NomeGuerra)
    session.close()
