from models import Session, Efetivo

def add_efetivo(nome, cpf, patente, imediato, idade):
    session = Session()
    efetivo = Efetivo(
        NomeGuerra=nome,
        CPF=cpf,
        Patente=patente,
        Imediato_NomeGuerra=imediato,
        Idade=idade
    )
    session.add(efetivo)
    session.commit()
    session.close()
    print(f"Adicionado: {nome}")

def list_efetivos():
    session = Session()
    efetivos = session.query(Efetivo).all()
    for e in efetivos:
        print(f"{e.NomeGuerra} - {e.Patente} - {e.Idade} anos")
    session.close()

def update_patente(nome, nova_patente):
    session = Session()
    efetivo = session.query(Efetivo).filter_by(NomeGuerra=nome).first()
    if efetivo:
        efetivo.Patente = nova_patente
        session.commit()
        print(f"Patente atualizada: {nome} -> {nova_patente}")
    else:
        print("Efetivo não encontrado.")
    session.close()

def delete_efetivo(nome):
    session = Session()
    efetivo = session.query(Efetivo).filter_by(NomeGuerra=nome).first()
    if efetivo:
        session.delete(efetivo)
        session.commit()
        print(f"Excluído: {nome}")
    else:
        print("Efetivo não encontrado.")
    session.close()
