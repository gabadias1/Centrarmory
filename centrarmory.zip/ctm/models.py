from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Boolean, Date, Time, Text
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

Base = declarative_base()

class Efetivo(Base):
    __tablename__ = 'Efetivo'
    NomeGuerra = Column(String(255), primary_key=True)
    CPF = Column(String(14), unique=True, nullable=False)
    Patente = Column(String(50))
    Imediato_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'))
    Idade = Column(Integer)

    imediato = relationship('Efetivo', remote_side=[NomeGuerra])

class PermissaoEfetivo(Base):
    __tablename__ = 'Permissao_Efetivo'
    ID_Permissao = Column(Integer, primary_key=True, autoincrement=True)
    NomeGuerra_Efetivo = Column(String(255), ForeignKey('Efetivo.NomeGuerra'), nullable=False)
    Tipo_Item = Column(String(50), nullable=False)
    Descricao_Permissao = Column(Text)

class TipoMovimentacao(Base):
    __tablename__ = 'Tipo_Movimentacao'
    ID_TipoMovimentacao = Column(Integer, primary_key=True, autoincrement=True)
    Descricao = Column(String(100), unique=True, nullable=False)

class AcessorioCategoria(Base):
    __tablename__ = 'Acessorio_Categoria'
    ID_Categoria = Column(Integer, primary_key=True, autoincrement=True)
    Tipo = Column(String(100))
    Marca = Column(String(100))
    Categoria_Acessorio = Column(String(100))
    Plataforma = Column(String(100))
    Nome_Acessorio = Column(String(255))

class ExplosivoCategoria(Base):
    __tablename__ = 'Explosivo_Categoria'
    ID_Categoria = Column(Integer, primary_key=True, autoincrement=True)
    Tipo_Explosivo = Column(String(100))
    ID_Permissao = Column(Integer, ForeignKey('Permissao_Efetivo.ID_Permissao'))

class MunicaoCategoria(Base):
    __tablename__ = 'Municao_Categoria'
    ID_Categoria = Column(Integer, primary_key=True, autoincrement=True)
    Calibre = Column(String(50))
    Fabricante = Column(String(100))
    ID_Permissao = Column(Integer, ForeignKey('Permissao_Efetivo.ID_Permissao'))

class SuprimentoCategoria(Base):
    __tablename__ = 'Suprimento_Categoria'
    ID_Categoria = Column(Integer, primary_key=True, autoincrement=True)
    Tipo_Suprimento = Column(String(100))
    ID_Permissao = Column(Integer, ForeignKey('Permissao_Efetivo.ID_Permissao'))

class VestimentaCategoria(Base):
    __tablename__ = 'Vestimenta_Categoria'
    ID_Categoria = Column(Integer, primary_key=True, autoincrement=True)
    Tipo_Vestimenta = Column(String(100))
    ID_Permissao = Column(Integer, ForeignKey('Permissao_Efetivo.ID_Permissao'))

class ArmaCategoria(Base):
    __tablename__ = 'Arma_Categoria'
    ID_Categoria = Column(Integer, primary_key=True, autoincrement=True)
    Marca = Column(String(100))
    Nomenclatura = Column(String(100))
    Calibre = Column(String(50))
    ID_Permissao = Column(Integer, ForeignKey('Permissao_Efetivo.ID_Permissao'))

class Movimentacoes(Base):
    __tablename__ = 'Movimentacoes'
    ID_Movimentacao = Column(Integer, primary_key=True, autoincrement=True)
    Data_Movimentacao = Column(Date, nullable=False)
    Hora_Movimentacao = Column(Time, nullable=False)
    Tipo_Movimentacao_ID = Column(Integer, ForeignKey('Tipo_Movimentacao.ID_TipoMovimentacao'), nullable=False)
    Responsavel_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'), nullable=False)
    NomeSolicitante_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'))
    Devolver_Status = Column(Boolean, default=False)
    Devolucao_Confirmada = Column(Boolean, default=False)

class AcessorioEstoque(Base):
    __tablename__ = 'Acessorio_Estoque'
    ID_Estoque = Column(Integer, primary_key=True, autoincrement=True)
    ID_Categoria = Column(Integer, ForeignKey('Acessorio_Categoria.ID_Categoria'), nullable=False)
    Responsavel_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'), nullable=False)
    Disponivel = Column(Boolean, default=True)
    ID_Movimentacao = Column(Integer)

class ExplosivoEstoque(Base):
    __tablename__ = 'Explosivo_Estoque'
    Lote = Column(String(255), primary_key=True)
    Validade = Column(Date)
    ID_Categoria = Column(Integer, ForeignKey('Explosivo_Categoria.ID_Categoria'), nullable=False)
    Quantidade_Inicial = Column(Integer, nullable=False)
    Quantidade_Atual = Column(Integer, nullable=False)
    Responsavel_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'), nullable=False)
    ID_Movimentacao = Column(Integer)

class MunicaoEstoque(Base):
    __tablename__ = 'Municao_Estoque'
    Lote = Column(String(255), primary_key=True)
    Validade = Column(Date)
    ID_Categoria = Column(Integer, ForeignKey('Municao_Categoria.ID_Categoria'), nullable=False)
    Quantidade_Inicial = Column(Integer, nullable=False)
    Quantidade_Atual = Column(Integer, nullable=False)
    Responsavel_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'), nullable=False)

class SuprimentoEstoque(Base):
    __tablename__ = 'Suprimento_Estoque'
    ID_Estoque = Column(Integer, primary_key=True, autoincrement=True)
    Validade = Column(Date)
    ID_Categoria = Column(Integer, ForeignKey('Suprimento_Categoria.ID_Categoria'), nullable=False)
    Responsavel_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'), nullable=False)
    Disponivel = Column(Boolean, default=True)
    ID_Movimentacao = Column(Integer)

class VestimentaEstoque(Base):
    __tablename__ = 'Vestimenta_Estoque'
    ID_Estoque = Column(Integer, primary_key=True, autoincrement=True)
    Tamanho = Column(String(10))
    ID_Categoria = Column(Integer, ForeignKey('Vestimenta_Categoria.ID_Categoria'), nullable=False)
    Cor = Column(String(50))
    Responsavel_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'), nullable=False)
    Disponivel = Column(Boolean, default=True)
    ID_Movimentacao = Column(Integer)

class ArmaEstoque(Base):
    __tablename__ = 'Arma_Estoque'
    Numero_Serie = Column(String(255), primary_key=True)
    ID_Categoria = Column(Integer, ForeignKey('Arma_Categoria.ID_Categoria'), nullable=False)
    Responsavel_NomeGuerra = Column(String(255), ForeignKey('Efetivo.NomeGuerra'), nullable=False)
    Disponivel = Column(Boolean, default=True)
    ID_Movimentacao = Column(Integer)

class DetalheMovimentacao(Base):
    __tablename__ = 'Detalhe_Movimentacao'
    ID_DetalheMovimentacao = Column(Integer, primary_key=True, autoincrement=True)
    ID_Movimentacao = Column(Integer, ForeignKey('Movimentacoes.ID_Movimentacao'), nullable=False)
    ID_Acessorio_Estoque = Column(Integer, ForeignKey('Acessorio_Estoque.ID_Estoque'))
    Lote_Explosivo_Estoque = Column(String(255), ForeignKey('Explosivo_Estoque.Lote'))
    Lote_Municao_Estoque = Column(String(255), ForeignKey('Municao_Estoque.Lote'))
    ID_Suprimento_Estoque = Column(Integer, ForeignKey('Suprimento_Estoque.ID_Estoque'))
    ID_Vestimenta_Estoque = Column(Integer, ForeignKey('Vestimenta_Estoque.ID_Estoque'))
    NumeroSerie_Arma_Estoque = Column(String(255), ForeignKey('Arma_Estoque.Numero_Serie'))
    Quantidade_Solicitada = Column(Integer)
    Quantidade_Devolvida = Column(Integer)

engine = create_engine("sqlite:///centrarmory.db")
Session = sessionmaker(bind=engine)

def create_tables():
    Base.metadata.create_all(engine)
