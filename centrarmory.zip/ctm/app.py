import crud
import consultas
from models import create_tables  
create_tables()

if __name__ == "__main__":
    create_tables()  

    crud.add_efetivo("JOAO", "123.456.789-00", "Soldado", None, 25)
    crud.list_efetivos()
    crud.update_patente("JOAO", "Cabo")
    crud.delete_efetivo("JOAO")

    consultas.consulta_maiores_de_30()
    consultas.consulta_patente("Major")
    consultas.consulta_com_imediato()